화면별 HTML 12개와 신규 CSS/JS 인계본입니다.
먼저 handoff/README.md 및 docs/04-developer-handoff.md를 읽어 주세요.
실행 가능한 전체 시연은 RMS_프로토타입.zip에 있습니다.
원문·공개 소스 분석 자료는 전체 작업 폴더의 reference/에 별도 보관합니다.
